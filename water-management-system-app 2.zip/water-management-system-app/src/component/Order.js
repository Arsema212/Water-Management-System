import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { getDistance, calculatePrice } from '../utils/calculation';
import '../styles/OrderScreen.css';

// Fix for default marker icons in Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

const LocationMap = ({ position, onPositionChange, providerLocation }) => {
  const map = useMap();
  const markerRef = useRef(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Center map when position changes
  useEffect(() => {
    if (position) {
      map.flyTo(position, map.getZoom());
      if (markerRef.current) {
        markerRef.current.setLatLng(position);
      }
    }
  }, [position, map]);

  // Handle map click
  const handleMapClick = (e) => {
    onPositionChange(e.latlng, '');
  };

  // Handle search (simplified - in real app you'd use a geocoding service)
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    // In a real app, you would call a geocoding API here
    // For demo, we'll just simulate a location near the provider
    const simulatedLocation = [
      providerLocation[0] + (Math.random() * 0.02 - 0.01),
      providerLocation[1] + (Math.random() * 0.02 - 0.01)
    ];
    
    onPositionChange(simulatedLocation, searchQuery);
  };

  return (
    <div className="map-container">
      <div className="map-search">
        <form onSubmit={handleSearch}>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for a location..."
          />
          <button type="submit">Search</button>
        </form>
      </div>
      <div className="map-wrapper">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {providerLocation && (
          <Marker position={providerLocation}>
            <Popup>Water Provider Location</Popup>
          </Marker>
        )}
        {position && (
          <Marker
            position={position}
            eventHandlers={{
              click: () => map.flyTo(position, map.getZoom()),
            }}
            ref={markerRef}
          >
            <Popup>Delivery Location</Popup>
          </Marker>
        )}
        <MapClickHandler onClick={handleMapClick} />
      </div>
    </div>
  );
};

const MapClickHandler = ({ onClick }) => {
  const map = useMap();
  useEffect(() => {
    map.on('click', onClick);
    return () => {
      map.off('click', onClick);
    };
  }, [map, onClick]);
  return null;
};

const OrderScreen = ({ selectedProvider, customerLocation, onOrderSubmit }) => {
    const [orderLocation, setOrderLocation] = useState(customerLocation);
    const [address, setAddress] = useState('');
    const [confirmedAddress, setConfirmedAddress] = useState('');
    const [quantity, setQuantity] = useState(1);
    const [price, setPrice] = useState(0);
    const [isValidated, setIsValidated] = useState(false);
    const [locationError, setLocationError] = useState('');
    const [mapView, setMapView] = useState(true); // Toggle between map and form view
    const mapRef = useRef(null);

    const providerLocation = [selectedProvider.lat, selectedProvider.lng];

    useEffect(() => {
        if (orderLocation && selectedProvider) {
            const distance = getDistance(
                orderLocation[0],
                orderLocation[1],
                selectedProvider.lat,
                selectedProvider.lng
            );
            const calculatedPrice = calculatePrice(distance, quantity);
            setPrice(calculatedPrice);
        }
    }, [orderLocation, quantity, selectedProvider]);

    const handlePositionChange = (newPosition, newAddress) => {
        setOrderLocation([newPosition.lat, newPosition.lng]);
        if (newAddress) {
            setAddress(newAddress);
            setConfirmedAddress(newAddress);
        }
        setLocationError('');
    };

    const handleAddressChange = (e) => {
        setAddress(e.target.value);
        setIsValidated(false);
    };

    const handleQuantityChange = (e) => {
        const value = parseInt(e.target.value);
        if (value >= 1 && value <= 100) {
            setQuantity(value);
        }
    };

    const validateOrder = () => {
        if (!orderLocation || !address.trim()) {
            setLocationError('Please select a valid delivery location');
            return;
        }
        setIsValidated(true);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!isValidated) {
            validateOrder();
            return;
        }
        
        const orderDetails = {
            providerId: selectedProvider.id,
            providerName: selectedProvider.name,
            deliveryAddress: confirmedAddress || address,
            location: orderLocation,
            quantity,
            price,
            date: new Date().toISOString()
        };
        
        onOrderSubmit(orderDetails);
    };

    return (
        <div className="order-screen">
            <div className="order-container">
                <h2 className="order-title">Place Your Water Order</h2>
                <div className="provider-summary">
                    <h3>Ordering from: {selectedProvider.name}</h3>
                    <p>{selectedProvider.location}</p>
                </div>
                
                <div className="location-selection">
                    <div className="location-toggle">
                        <button
                            className={mapView ? 'active' : ''}
                            onClick={() => setMapView(true)}
                        >
                            Select on Map
                        </button>
                        <button
                            className={!mapView ? 'active' : ''}
                            onClick={() => setMapView(false)}
                        >
                            Enter Address
                        </button>
                    </div>
                    
                    {mapView ? (
                        <div className="map-view">
                            <MapContainer
                                center={orderLocation || customerLocation}
                                zoom={13}
                                style={{ height: '400px', width: '100%', borderRadius: '8px' }}
                                ref={mapRef}
                            >
                                <LocationMap
                                    position={orderLocation}
                                    onPositionChange={handlePositionChange}
                                    providerLocation={providerLocation}
                                />
                            </MapContainer>
                            <div className="selected-location">
                                <h4>Selected Location:</h4>
                                {confirmedAddress ? (
                                    <p>{confirmedAddress}</p>
                                ) : orderLocation ? (
                                    <p>Map coordinates: {orderLocation[0].toFixed(4)}, {orderLocation[1].toFixed(4)}</p>
                                ) : (
                                    <p>No location selected</p>
                                )}
                            </div>
                        </div>
                    ) : (
                        <form onSubmit={(e) => e.preventDefault()} className="address-form">
                            <div className="form-group">
                                <label htmlFor="delivery-address">Delivery Address</label>
                                <input
                                    type="text"
                                    id="delivery-address"
                                    value={address}
                                    onChange={handleAddressChange}
                                    placeholder="Enter your full delivery address"
                                    className={locationError ? 'error' : ''}
                                />
                                {locationError && <p className="error-message">{locationError}</p>}
                            </div>
                            <button 
                                type="button" 
                                className="verify-button"
                                onClick={() => {
                                    // In a real app, this would trigger geocoding
                                    setConfirmedAddress(address);
                                    setLocationError('');
                                }}
                            >
                                Verify Address
                            </button>
                        </form>
                    )}
                </div>
                
                <div className="quantity-selector">
                    <label htmlFor="water-quantity">Water Quantity (liters)</label>
                    <input
                        type="number"
                        id="water-quantity"
                        min="1"
                        max="100"
                        value={quantity}
                        onChange={handleQuantityChange}
                    />
                </div>
                
                <div className="price-summary">
                    <h3>Order Summary</h3>
                    <div className="price-details">
                        <div className="price-row">
                            <span>Base Price:</span>
                            <span>${(price / quantity).toFixed(2)}/liter</span>
                        </div>
                        <div className="price-row">
                            <span>Quantity:</span>
                            <span>{quantity} liters</span>
                        </div>
                        <div className="price-row">
                            <span>Delivery Fee:</span>
                            <span>${(price - (price / quantity) * quantity).toFixed(2)}</span>
                        </div>
                        <div className="price-row total">
                            <span>Total Price:</span>
                            <span>${price.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                
                {!isValidated ? (
                    <button onClick={validateOrder} className="validate-button">
                        Validate Order
                    </button>
                ) : (
                    <div className="validation-success">
                        <p>✓ Order validated successfully</p>
                        <button onClick={handleSubmit} className="submit-button">
                            Proceed to Checkout
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default OrderScreen;