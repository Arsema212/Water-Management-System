import React, { useState } from 'react';
import { getDistance } from '../utils/distance';
import '../styles/ProviderList.css';
import OrderScreen from './Order';

const ProviderList = ({ providers, customerLocation }) => {
    const [selectedProvider, setSelectedProvider] = useState(null);

    if (selectedProvider) {
        return (
            <OrderScreen 
                selectedProvider={selectedProvider}
                customerLocation={customerLocation}
                onOrderSubmit={(orderDetails) => {
                    // Handle order submission here
                    console.log('Order submitted:', orderDetails);
                    // You might want to navigate away or show a success message
                }}
                onBack={() => setSelectedProvider(null)} // Add back button functionality
            />
        );
    }

    return (
        <div className="provider-list">
            <div className="provider-cards">
                {providers.map((provider) => {
                    const distance = getDistance(
                        customerLocation[0],
                        customerLocation[1],
                        provider.lat,
                        provider.lng
                    );

                    return (
                        <div className="provider-card" key={provider.id}>
                            <div className="provider-info">
                                <h3>{provider.name}</h3>
                                <p>{provider.location}</p>
                                <p>{distance.toFixed(2)} km away</p>
                            </div>
                            <button 
                                className="order-button" 
                                onClick={() => setSelectedProvider(provider)}
                            >
                                Order
                            </button>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default ProviderList;