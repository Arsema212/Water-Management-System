import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const RegisterProvider = () => {
    const [providerName, setProviderName] = useState('');
    const [location, setLocation] = useState('');
    const [searchAddress, setSearchAddress] = useState('');
    const [coords, setCoords] = useState({lat: null, lon: null });
    const navigate = useNavigate();

    const handleLocationSearch = async () => {
        if (!searchAddress) return;
    
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchAddress)}`);
            const data = await response.json();
            if (data.length > 0) {
                const { lat, lon, display_name } = data[0];
    
               // Check if the location contains "Addis Ababa"
                if (display_name.includes("Addis Ababa")) {
                    setLocation(display_name);
                    setCoords({ lat, lon });
                } else {
                    alert('Only providers in Addis Ababa can register.');
                }
            } else {
                alert('Location not found. Please try another address.');
            }
        } catch (error) {
            console.error('Error fetching location:', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const providerData = {
            name: providerName,
            location: location,
            latitude: coords.lat,
            longitude: coords.lan,
        };

        try {
            const response = await fetch('/api/providers', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(providerData),
            });

            if (response.ok) {
                console.log('Provider registered successfully:', providerData);
            } else {
                console.error('Failed to register provider');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div>
            <h2>Register Provider</h2>
            <form onSubmit={handleSubmit}>
                <input 
                    type="text" 
                    placeholder="Provider Name" 
                    value={providerName} 
                    onChange={(e) => setProviderName(e.target.value)} 
                    required 
                />
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <input 
                        type="text" 
                        placeholder="Search Location" 
                        value={searchAddress} 
                        onChange={(e) => setSearchAddress(e.target.value)} 
                    />
                    <button 
                        type="button" 
                        onClick={handleLocationSearch} 
                        style={{ marginLeft: '10px' }}
                    >
                        Search
                    </button>
                </div>
                <input 
                    name=""
                    type="text" 
                    placeholder="Location" 
                    value={location} 
                    readOnly 
                    style={{ marginTop: '10px', width: '85%' }} 
                />
                <button type="submit">Register</button>
            </form>
        </div>
    );
};

export default RegisterProvider;