import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

const Map = () => {
  const [markerPosition, setMarkerPosition] = useState([9.046599, 38.763332]); // Default position

  const handleMapDblClick = async (event) => {
    const newPosition = [event.latlng.lat, event.latlng.lng];
    setMarkerPosition(newPosition);

    // Fetch the place name using reverse geocoding
    const placeName = await getPlaceName(newPosition);
    
    // Store selected location in local storage
    localStorage.setItem('selectedLocation', JSON.stringify({ placeName }));
    
    // Redirect back to the admin dashboard
    window.location.href = '/admin'; // Change to your admin route
  };

  const getPlaceName = async ([lat, lng]) => {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
      const data = await response.json();
      return data.display_name || 'Selected Location';
    } catch (error) {
      console.error('Error fetching place name:', error);
      return 'Selected Location';
    }
  };

  return (
    <MapContainer 
      center={markerPosition} 
      zoom={13} 
      style={{ height: "400px", width: "800px" }} 
      onDblClick={handleMapDblClick} // Change to double click
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      <Marker position={markerPosition}>
        <Popup>Your selected location.</Popup>
      </Marker>
    </MapContainer>
  );
};

export default Map;